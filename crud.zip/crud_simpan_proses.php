<?php
include('crud_koneksi.php');
if(isset($_POST['simpan'])){
$nim      = $_POST['nim'];
$nama     = $_POST['nama'];
$semester = $_POST['semester']; 
$input = mysql_query("INSERT INTO tbl_mahasiswa VALUES(NULL, '$nim','$nama','$semester')") or die(mysql_error());
if($input){
echo '
<script type="text/javascript">
alert("Data berhasil disimpan, klik OK untuk melanjutkan!");
window.location.href="index.php"		        
</script>
';
}else{
echo '<div align="center">Gagal disimpan!</div>';
}
}
?> 