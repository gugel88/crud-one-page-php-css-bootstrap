<?php
include('crud_koneksi.php');
if(isset($_POST['rubah'])){
$id     = $_POST['id'];
$nim    = $_POST['nim'];
$nama   = $_POST['nama'];
$semester = $_POST['semester']; 
$update = mysql_query("UPDATE tbl_mahasiswa SET nim='$nim', nama='$nama', semester='$semester' WHERE id='$id'") or die(mysql_error());
if($update){
echo '
<script type="text/javascript">
alert("Data berhasil dirubah, klik OK untuk melanjutkan!");
window.location.href="index.php"		        
</script>
';
}else{
echo 'Gagal menyimpan data! ';
echo '<a href="index.php?id='.$id.'">Kembali</a>';
}
}else{
}
?>   