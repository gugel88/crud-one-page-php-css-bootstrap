<?php
include('crud_koneksi.php');
if(isset($_GET['id'])){
	$id = $_GET['id'];
	$cek = mysql_query("SELECT id FROM tbl_mahasiswa WHERE id='$id'") or die(mysql_error());
	if(mysql_num_rows($cek) == 0){
		echo '<script>window.history.back()</script>';
	}else{
		$del = mysql_query("DELETE FROM tbl_mahasiswa WHERE id='$id'");
		if($del){
			echo '
			<script type="text/javascript">
			window.location.href="index.php"		        
			</script>
			';
		}else{
			echo 'Gagal menghapus data! ';
			echo '<a href="index.php">Kembali</a>';
		}
	}
}else{
	echo '<script>window.history.back()</script>';
}
?>