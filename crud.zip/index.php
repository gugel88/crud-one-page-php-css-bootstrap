<?php
error_reporting(0); 
include('crud_koneksi.php'); 
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Crud - GUGEL88.COM</title>
  <link rel="shortcut icon" href="assets/dist/img/icon.png" type="image/x-icon" />
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="assets/css/ionicons.min.css">
  <link rel="stylesheet" href="assets/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="assets/dist/css/skins/_all-skins.min.css">
</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <a href="index.php" class="logo">
      <span class="logo-mini">G88</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>CR</b>UD</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

    </nav>
  </header>
  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="assets/dist/img/icon.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>GUGEL88.COM</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <ul class="sidebar-menu">
        <li class="header">MENU</li>
        <li class="treeview">
          <a href="index.php">
            <i class="fa fa-dashboard"></i> <span>Crud</span>
            <span class="pull-right-container">
            </span>
          </a>
        </li>                      
    </section>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Crud
        <small>Versi 0.0.1</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Crud</li>
      </ol>
    </section>


    <section class="content">
      <div class="row">
        <!--/Input Data Mahasiswa\-->
        <div class="col-md-3">
            <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Input Mahasiswa</h3>
              </div>             
              <form method="post" action="crud_simpan_proses.php">
                <div class="box-body">
                  <div class="form-group">
                    <label for="nim">NIM</label>
                    <input type="text" class="form-control" id="nim" name="nim" placeholder="Masukan NIM" required>
                  </div>
                  <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukan Nama" required>
                  </div>
                  <div class="form-group">
                    <label>Semester</label>
                    <select class="form-control" name="semester" id="semester" required>
                      <option>Pilih</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7">7</option>
                      <option value="8">8</option>
                    </select>
                  </div>                                                                                  
                  <div class="form-group">
                    <button type="reset" class="btn btn-danger">Ulangi</button> <button type="submit" name="simpan" id="simpan" class="btn btn-primary">Simpan</button>
                  </div>
                </div>
              </form>
            </div>
        </div>
        <!--\end Input Data Mahasiswa/-->


        <!--/Tampilkan Data Mahasiswa\-->
        <div class="col-md-6">
            <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Output Mahasiswa</h3>
              </div>
            <div class="box-body no-padding">
              <table class="table table-striped">            
                  <tr>
                    <th>No.</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Semester</th>
                    <th>Aksi</th>
                  </tr>
                  <?php
                  $query = mysql_query("SELECT * FROM tbl_mahasiswa ORDER BY nim DESC") or die(mysql_error());
                  if(mysql_num_rows($query) == 0){
                  echo '<div align="center">Tidak ada data!</div>';
                  }else{
                    $no = 1;
                    while($data = mysql_fetch_assoc($query)){                    
                    echo '<tr>';
                      echo '<td>'.$no.'</td>';
                      echo '<td>'.$data['nim'].'</td>'; 
                      echo '<td>'.$data['nama'].'</td>';
                      echo '<td>'.$data['semester'].'</td>';
                      echo '<td>
                            <a href="index.php?id='.$data['id'].'"><button type="get" class="btn btn-sm btn-primary" name="edit" id="edit" >Edit</button></a>
                            <a href="crud_hapus_proses.php?id='.$data['id'].'" onclick="return confirm(\'Yakin ingin menghapus data ini?\')"><button class="btn btn-sm btn-danger">Hapus</button></a>
                            </td>';              
                      echo '</tr>';
                      $no++;
                    }
                  }
                  ?>
              </table>
            </div>
            </div>
        </div>
        <!--\end Tampilkan Data Mahasiswa/-->


        <!--/Edit Data Mahasiswa\-->     
        <div class="col-md-3">
            <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Edit Mahasiswa</h3>
              </div>

              <?php
              $id = $_GET['id'];
              $show = mysql_query("SELECT * FROM tbl_mahasiswa WHERE id='$id'");
              if(mysql_num_rows($show) == 0){
              }else{
                $data = mysql_fetch_assoc($show);
              }
              ?>              
              <form name="edit" method="post" action="crud_edit_proses.php">
              <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="box-body">
                  <div class="form-group">
                    <label for="nim">NIM</label>
                    <input type="text" class="form-control" id="nim" name="nim" value="<?php echo $data['nim']; ?>" required placeholder="Masukan NIM">
                  </div>
                  <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $data['nama']; ?>" required placeholder="Masukan Nama">
                  </div>
                  <div class="form-group">
                    <select class="form-control" name="semester" id="semester" required>
                    <option>Pilih</option>
	                    <option value="1" <?php if($data['semester'] == '1'){ echo 'selected'; } ?>>1</option>
	                    <option value="2" <?php if($data['semester'] == '2'){ echo 'selected'; } ?>>2</option>
	                    <option value="3" <?php if($data['semester'] == '3'){ echo 'selected'; } ?>>3</option>  
	                    <option value="4" <?php if($data['semester'] == '4'){ echo 'selected'; } ?>>4</option>  
	                    <option value="5" <?php if($data['semester'] == '5'){ echo 'selected'; } ?>>5</option>
	                    <option value="6" <?php if($data['semester'] == '6'){ echo 'selected'; } ?>>6</option>
	                    <option value="7" <?php if($data['semester'] == '7'){ echo 'selected'; } ?>>7</option>
	                    <option value="8" <?php if($data['semester'] == '8'){ echo 'selected'; } ?>>8</option>  
                    </select>
                  </div>                                                                                  
                  <div class="form-group">
                    <button type="submit" name="rubah" class="btn btn-primary">Rubah</button>
                  </div>
                </div>
              </form>
            </div>
        </div>
        <!--\end Edit Data Mahasiswa/-->

      </div>
    </section>
  </div>


  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Versi</b> 0.0.1
    </div>
    Copyright &copy; 2017 <a href="http://www.gugel88.com/" target="_blank" title="GUGEL88.COM"><strong>GUGEL88.COM</strong></a>
  </footer>


<script src="assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/plugins/fastclick/fastclick.js"></script>
<script src="assets/dist/js/app.min.js"></script>
<script src="assets/dist/js/demo.js"></script>
</body>
</html>